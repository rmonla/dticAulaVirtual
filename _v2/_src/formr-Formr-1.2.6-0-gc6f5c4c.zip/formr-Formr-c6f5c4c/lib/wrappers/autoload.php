<?php

# load framework traits
require_once 'bootstrap.php';
require_once 'bulma.php';